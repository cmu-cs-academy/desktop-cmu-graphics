/* PYGEO */
use pyo3::Bound;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyModule;

use geo::BooleanOps;
use geo::{LineString, MultiPolygon, Polygon};
use winit::window::Fullscreen::Borderless;

// type aliases
type PyLineString = Vec<[f64; 2]>;
type PyPolygon = Vec<PyLineString>;
type PyMultiPolygon = Vec<PyPolygon>;

// conversions from Python to Rust
fn py_polygon_to_polygon(poly: PyPolygon) -> Polygon<f64> {
    let mut line_strings = poly.into_iter().map(LineString::from);

    match line_strings.next() {
        Some(exterior) => Polygon::new(exterior, line_strings.collect()),
        None => Polygon::empty(),
    }
}

fn py_multi_polygon_to_multi_polygon(multi_poly: PyMultiPolygon) -> MultiPolygon<f64> {
    let polys = multi_poly.into_iter().map(py_polygon_to_polygon).collect();
    MultiPolygon::new(polys)
}

// conversions from Rust to Python
fn line_string_to_vec(line_string: &LineString<f64>) -> PyLineString {
    line_string.points().map(|p| [p.x(), p.y()]).collect()
}

fn polygon_to_py_polygon(poly: Polygon<f64>) -> PyPolygon {
    let holes = poly.interiors().iter().map(line_string_to_vec);
    let exterior = line_string_to_vec(poly.exterior());

    std::iter::once(exterior).chain(holes).collect()
}

fn multi_polygon_to_py_multi_polygon(multi_poly: MultiPolygon<f64>) -> PyMultiPolygon {
    multi_poly.into_iter().map(polygon_to_py_polygon).collect()
}

// Unions a vector of PyMultiPolygons
#[pyfunction]
fn union(py_polys: Vec<PyMultiPolygon>) -> PyResult<PyMultiPolygon> {
    let union_result_or_none = py_polys
        .into_iter()
        .map(py_multi_polygon_to_multi_polygon)
        .reduce(|u, m| m.union(&u));

    match union_result_or_none {
        Some(union_result) => Ok(multi_polygon_to_py_multi_polygon(union_result)),
        None => Err(PyValueError::new_err(
            "union must be given at least one MultiPolygon as input",
        )),
    }
}

fn segmentsIntersect(
    x1: f64,
    y1: f64,
    x2: f64,
    y2: f64,
    x3: f64,
    y3: f64,
    x4: f64,
    y4: f64,
) -> bool {
    let dxa = x2 - x1;
    let dya = y2 - y1;
    let dxb = x4 - x3;
    let dyb = y4 - y3;
    let s = if (-dxb * dya + dxa * dyb) == 0.0 {
        f64::INFINITY
    } else {
        (-dya * (x1 - x3) + dxa * (y1 - y3)) / (-dxb * dya + dxa * dyb)
    };
    let t = if (-dxb * dya + dxa * dyb) == 0.0 {
        f64::INFINITY
    } else {
        (dxb * (y1 - y3) - dyb * (x1 - x3)) / (-dxb * dya + dxa * dyb)
    };
    return s >= 0.0 && s <= 1.0 && t >= 0.0 && t <= 1.0;
}

#[pyfunction]
fn edgesIntersect(pts1: Vec<[f64; 2]>, pts2: Vec<[f64; 2]>) -> bool {
    let mut k;
    for i in 0..pts1.len() {
        let (x1, y1) = (pts1[i][0], pts1[i][1]);
        k = (i + 1) % pts1.len();
        let (x2, y2) = (pts1[k][0], pts1[k][1]);
        for j in 0..pts2.len() {
            let (x3, y3) = (pts2[j][0], pts2[j][1]);
            k = (j + 1) % pts2.len();
            let (x4, y4) = (pts2[k][0], pts2[k][1]);
            if segmentsIntersect(x1, y1, x2, y2, x3, y3, x4, y4) {
                return true;
            }
        }
    }
    return false;
}
/* PYGEO */

/* WYVERN */
use std::f32::consts::PI;
use std::fs::File;
use std::io::Read;
use std::io::Write;

use pyo3::exceptions::PyRuntimeError;
use pyo3::types::{PyByteArray, PyBytes};

use skia_safe::{
    Color, Color4f, ColorSpace, ColorType, Font, FontMgr, FontStyle, Image, ImageInfo, Matrix,
    Paint, PaintJoin, Path, PathBuilder, PathEffect, Point, RRect, Rect, TileMode, Typeface,
    Vector, font_style, gradient, surfaces,
};

const RAD_TO_DEG: f32 = 180.0 / PI;
const ORIGIN: Point = Point::new(0.0, 0.0);

fn create_skia_surface(width: i32, height: i32, scale_factor: f64) -> PyResult<skia_safe::Surface> {
    let width = width.max(1);
    let height = height.max(1);
    let image_info = ImageInfo::new(
        (width, height),
        ColorType::RGBA8888,
        skia_safe::AlphaType::Premul,
        ColorSpace::new_srgb(),
    );
    let mut surface = surfaces::raster(&image_info, None, None)
        .ok_or_else(|| PyRuntimeError::new_err("Failed to create Skia raster surface"))?;
    let scale = scale_factor as f32;
    surface.canvas().scale((scale, scale));
    surface.canvas().clear(Color::WHITE);
    Ok(surface)
}

fn new_path_and_move(p: Point) -> PathBuilder {
    let mut new_path = PathBuilder::new();
    new_path.move_to(p);
    new_path
}

fn new_path_and_line(p: Point) -> PathBuilder {
    let mut new_path = PathBuilder::new();
    new_path.line_to(p);
    new_path
}

#[pyclass(from_py_object)]
#[derive(Clone)]
enum LineJoin {
    MITER,
    ROUND,
    BEVEL,
}

#[pyclass(from_py_object)]
#[derive(Clone)]
enum FontWeight {
    BOLD,
    NORMAL,
}

fn py_to_skia_weight(weight: FontWeight) -> font_style::Weight {
    match weight {
        FontWeight::BOLD => font_style::Weight::BOLD,
        FontWeight::NORMAL => font_style::Weight::NORMAL,
    }
}

#[pyclass(from_py_object)]
#[derive(Clone)]
enum FontSlant {
    ITALIC,
    NORMAL,
    OBLIQUE,
}

fn py_to_skia_slant(slant: FontSlant) -> font_style::Slant {
    match slant {
        FontSlant::ITALIC => font_style::Slant::Italic,
        FontSlant::NORMAL => font_style::Slant::Upright,
        FontSlant::OBLIQUE => font_style::Slant::Oblique,
    }
}

// Arial, or the platform's default face when no font maps to Arial.
// Linux systems may not have Arial installed, so don't crash!
fn get_arial(font_mgr: &FontMgr, style: FontStyle) -> PyResult<Typeface> {
    font_mgr
        .match_family_style("Arial", style)
        .or_else(|| font_mgr.legacy_make_typeface(None, style))
        .ok_or_else(|| {
            PyRuntimeError::new_err(
                "No fonts were found on this computer.",
            )
        })
}

#[pyclass(from_py_object)]
#[derive(Clone)]
enum Gradient {
    LinearGradient(f32, f32, f32, f32),
    RadialGradient(f32, f32, f32),
}

#[pyclass(module = "wyvern")]
struct WyvernImage {
    image: Image,
    width: i32,
    height: i32,
    opaque: bool,
}

fn image_info_for(width: i32, height: i32, opaque: bool) -> ImageInfo {
    let alpha = if opaque {
        skia_safe::AlphaType::Opaque
    } else {
        skia_safe::AlphaType::Premul
    };
    ImageInfo::new(
        (width, height),
        ColorType::RGBA8888,
        alpha,
        ColorSpace::new_srgb(),
    )
}

#[pymethods]
impl WyvernImage {
    #[new]
    fn create(
        data: Bound<'_, PyByteArray>,
        width: i32,
        height: i32,
        row_bytes: usize,
    ) -> PyResult<Self> {
        let bytes = unsafe { data.as_bytes() };
        let opaque = bytes.iter().skip(3).step_by(4).all(|&a| a == 255);
        let image_info = image_info_for(width, height, opaque);
        let image = skia_safe::images::raster_from_data(
            &image_info,
            skia_safe::Data::new_copy(bytes),
            row_bytes,
        )
        .ok_or(PyRuntimeError::new_err(
            "Issue with creating image from data",
        ))?;
        Ok(WyvernImage {
            image,
            width,
            height,
            opaque,
        })
    }

    fn scaled(&self, width: i32, height: i32) -> PyResult<WyvernImage> {
        let width = width.max(1);
        let height = height.max(1);
        let image_info = image_info_for(width, height, self.opaque);
        let mut surface = surfaces::raster(&image_info, None, None)
            .ok_or_else(|| PyRuntimeError::new_err("Failed to create scaling surface"))?;
        let dst = Rect::from_wh(width as f32, height as f32);
        surface.canvas().draw_image_rect_with_sampling_options(
            &self.image,
            None,
            dst,
            skia_safe::SamplingOptions::new(
                skia_safe::FilterMode::Linear,
                skia_safe::MipmapMode::None,
            ),
            &Paint::default(),
        );
        let image = surface.image_snapshot();
        Ok(WyvernImage {
            image,
            width,
            height,
            opaque: self.opaque,
        })
    }

    #[getter]
    fn width(&self) -> i32 {
        self.width
    }

    #[getter]
    fn height(&self) -> i32 {
        self.height
    }
}

type CanvasSettings = (Font, Vec<Color4f>, Vec<f32>, Paint);

#[pyclass(unsendable, module = "wyvern")]
struct Canvas {
    skia_surface: skia_safe::Surface,
    path: Option<skia_safe::PathBuilder>,
    font_mgr: FontMgr,
    font: Font,
    gradient_colors: Vec<Color4f>,
    gradient_offsets: Vec<f32>,
    paint: Paint,
    state_stack: Vec<CanvasSettings>,
}

#[pymethods]
impl Canvas {
    fn save(&mut self) {
        self.skia_surface.canvas().save();
        self.state_stack.push((
            self.font.clone(),
            self.gradient_colors.clone(),
            self.gradient_offsets.clone(),
            self.paint.clone(),
        ));
    }

    fn restore(&mut self) -> PyResult<()> {
        self.skia_surface.canvas().restore();
        let (prev_font, prev_gcolor, prev_goff, prev_paint) = self
            .state_stack
            .pop()
            .ok_or(PyRuntimeError::new_err("Restore must be preceded by save"))?;
        self.font = prev_font;
        self.gradient_colors = prev_gcolor;
        self.gradient_offsets = prev_goff;
        self.paint = prev_paint;
        Ok(())
    }

    fn translate(&mut self, x: f32, y: f32) {
        self.skia_surface.canvas().translate(Vector::new(x, y));
    }

    fn rotate(&mut self, angle: f32) {
        self.skia_surface.canvas().rotate(angle * RAD_TO_DEG, None);
    }

    #[pyo3(signature = (xx = 1.0, yx = 0.0, xy = 0.0, yy = 1.0, x0 = 0.0, y0 = 0.0))]
    fn transform(&mut self, xx: f32, yx: f32, xy: f32, yy: f32, x0: f32, y0: f32) {
        let matrix = Matrix::new_all(xx, xy, x0, yx, yy, y0, 0.0, 0.0, 1.0);
        self.skia_surface.canvas().concat(&matrix);
    }

    fn new_path(&mut self) {
        self.path = Some(PathBuilder::new());
    }

    fn move_to(&mut self, x: f32, y: f32) {
        let point = Point::new(x, y);
        self.path
            .get_or_insert_with(|| new_path_and_move(point))
            .move_to(point);
    }

    fn line_to(&mut self, x: f32, y: f32) {
        let point = Point::new(x, y);
        self.path
            .get_or_insert_with(|| new_path_and_move(point))
            .line_to(point);
    }

    fn rel_line_to(&mut self, x: f32, y: f32) -> PyResult<()> {
        self.path
            .as_mut()
            .ok_or_else(|| PyRuntimeError::new_err("Path does not exist for rel_line_to"))?
            .r_line_to(Vector::new(x, y));
        Ok(())
    }

    fn curve_to(&mut self, x1: f32, y1: f32, x2: f32, y2: f32, x3: f32, y3: f32) {
        let first_point = Point::new(x1, y1);
        self.path
            .get_or_insert_with(|| new_path_and_move(first_point))
            .cubic_to(first_point, Point::new(x2, y2), Point::new(x3, y3));
    }

    fn rel_curve_to(
        &mut self,
        x1: f32,
        y1: f32,
        x2: f32,
        y2: f32,
        x3: f32,
        y3: f32,
    ) -> PyResult<()> {
        self.path
            .as_mut()
            .ok_or_else(|| PyRuntimeError::new_err("Path does not exist for rel_curve_to"))?
            .r_cubic_to(
                Vector::new(x1, y1),
                Vector::new(x2, y2),
                Vector::new(x3, y3),
            );
        Ok(())
    }

    fn rectangle(&mut self, left: f32, top: f32, width: f32, height: f32) {
        let r = Rect::new(left, top, left + width, top + height);
        self.path
            .get_or_insert_with(|| new_path_and_move(r.tl()))
            .add_rect(r, None, None);
    }

    fn round_rectangle(
        &mut self,
        left: f32,
        top: f32,
        width: f32,
        height: f32,
        x_rad: f32,
        y_rad: f32,
    ) {
        let r = Rect::new(left, top, left + width, top + height);
        self.path
            .get_or_insert_with(|| new_path_and_move(r.tl()))
            .add_rrect(RRect::new_rect_xy(r, x_rad, y_rad), None, None);
    }

    fn arc(&mut self, xc: f32, yc: f32, radius: f32, angle1: f32, mut angle2: f32) {
        let r = Rect::new(xc - radius, yc - radius, xc + radius, yc + radius);
        let start_point = Point::new(xc + (radius * angle1.cos()), yc + (radius * angle1.sin()));
        while angle2 < angle1 {
            angle2 += 2.0 * PI
        }
        self.path
            .get_or_insert_with(|| new_path_and_line(start_point))
            .add_arc(r, angle1 * RAD_TO_DEG, (angle2 - angle1) * RAD_TO_DEG);
    }

    fn close_path(&mut self) {
        if let Some(pb) = self.path.as_mut() {
            pb.close();
        }
    }

    #[pyo3(signature = (r, g, b, a = None))]
    fn set_source_rgba(&mut self, r: f32, g: f32, b: f32, a: Option<f32>) {
        self.paint.set_shader(None);
        self.paint
            .set_color4f(Color4f::new(r, g, b, a.unwrap_or(1.0)), None);
    }

    fn set_source_rgb(&mut self, r: f32, g: f32, b: f32) {
        self.set_source_rgba(r, g, b, Some(1.0));
    }

    fn set_line_width(&mut self, width: f32) {
        self.paint.set_stroke_width(width);
    }

    fn set_line_join(&mut self, join: LineJoin) {
        match join {
            LineJoin::MITER => self.paint.set_stroke_join(PaintJoin::Miter),
            LineJoin::ROUND => self.paint.set_stroke_join(PaintJoin::Round),
            LineJoin::BEVEL => self.paint.set_stroke_join(PaintJoin::Bevel),
        };
    }

    #[pyo3(signature = (dashes, offset = 0.0))]
    fn set_dash(&mut self, dashes: Vec<f32>, offset: f32) {
        let path_effect = PathEffect::dash(&dashes, offset);
        self.paint.set_path_effect(path_effect);
    }

    fn select_font_face(
        &mut self,
        family_name: String,
        weight: FontWeight,
        slant: FontSlant,
    ) -> PyResult<()> {
        let style = FontStyle::new(
            py_to_skia_weight(weight),
            font_style::Width::NORMAL,
            py_to_skia_slant(slant),
        );
        // legacy_make_typeface falls back to the platform's default face for an
        // unknown family, which is what cairo's select_font_face did (Helvetica on
        // macOS). Falling back to Arial ourselves would render unavailable fonts
        // differently than cairo did.
        if let Some(typeface) = self
            .font_mgr
            .legacy_make_typeface(Some(family_name.as_str()), style)
        {
            self.font.set_typeface(typeface);
        } else {
            self.font.set_typeface(get_arial(&self.font_mgr, style)?);
        }
        Ok(())
    }

    fn set_font_size(&mut self, size: f32) -> PyResult<()> {
        self.font.set_size(size);
        Ok(())
    }

    fn text_extents(&mut self, text: String) -> PyResult<(f32, f32, f32, f32, f32, f32)> {
        let font = self.font.as_ref();
        let (width, _) = Font::measure_str(font, &text, Some(&self.paint));
        // Font::measure_str's bounds are the rasterizer's glyph-mask bounds, which
        // are rounded out to whole pixels and padded for anti-aliasing. Cairo's
        // text_extents reports the exact outline ink extents, so measure the text
        // path instead to keep label dimensions the same as they were under cairo.
        let rect = Path::from_str(&text, ORIGIN, font).compute_tight_bounds();
        Ok((
            rect.left(),
            rect.top(),
            rect.right() - rect.left(),
            rect.height(),
            width,
            rect.bottom(),
        ))
    }

    fn text_path(&mut self, text: String) -> PyResult<()> {
        let font = self.font.as_ref();
        let point = self
            .path
            .as_ref()
            .and_then(|pb| pb.get_last_pt())
            .unwrap_or(ORIGIN);
        let text_path = Path::from_str(&text, point, font);
        self.path
            .get_or_insert(PathBuilder::new_path(&text_path))
            .add_path(&text_path, None);
        Ok(())
    }

    fn show_text(&mut self, text: String) -> PyResult<()> {
        let font = self.font.as_ref();
        let point = self
            .path
            .as_ref()
            .and_then(|pb| pb.get_last_pt())
            .unwrap_or(ORIGIN);
        let mut paint = self.paint.clone();
        paint.set_stroke(false);
        paint.set_anti_alias(true);
        self.skia_surface
            .canvas()
            .draw_str(&text, point, font, &paint);
        Ok(())
    }

    fn paint_with_alpha(&mut self, a: f32) {
        let mut paint = self.paint.clone();
        paint.set_alpha_f(a);
        paint.set_anti_alias(true);
        self.skia_surface.canvas().draw_paint(&paint);
    }

    fn clip_preserve(&mut self) -> PyResult<()> {
        let path = if let Some(pb) = &self.path {
            Ok(pb.snapshot())
        } else {
            Err(PyRuntimeError::new_err(
                "Path does not exist for clip_preserve",
            ))
        }?;
        self.skia_surface.canvas().clip_path(&path, None, true);
        Ok(())
    }

    fn clip(&mut self) -> PyResult<()> {
        let path = self
            .path
            .take()
            .ok_or(PyRuntimeError::new_err("Path does not exist for clip"))?
            .detach();
        self.skia_surface.canvas().clip_path(&path, None, true);
        Ok(())
    }

    fn stroke_preserve(&mut self) -> PyResult<()> {
        let path = if let Some(pb) = &self.path {
            Ok(pb.snapshot())
        } else {
            Err(PyRuntimeError::new_err(
                "Path does not exist for stroke_preserve",
            ))
        }?;
        let mut paint = self.paint.clone();
        paint.set_stroke(true);
        paint.set_anti_alias(true);
        self.skia_surface.canvas().draw_path(&path, &paint);
        Ok(())
    }

    fn stroke(&mut self) -> PyResult<()> {
        let path = self
            .path
            .take()
            .ok_or(PyRuntimeError::new_err("Path does not exist for stroke"))?
            .detach();
        let mut paint = self.paint.clone();
        paint.set_stroke(true);
        paint.set_anti_alias(true);
        self.skia_surface.canvas().draw_path(&path, &paint);
        Ok(())
    }

    fn fill_preserve(&mut self) -> PyResult<()> {
        let path = if let Some(pb) = &self.path {
            Ok(pb.snapshot())
        } else {
            Err(PyRuntimeError::new_err(
                "Path does not exist for fill_preserve",
            ))
        }?;
        let mut paint = self.paint.clone();
        paint.set_stroke(false);
        paint.set_anti_alias(true);
        self.skia_surface.canvas().draw_path(&path, &paint);
        Ok(())
    }

    fn fill(&mut self) -> PyResult<()> {
        let path = self
            .path
            .take()
            .ok_or(PyRuntimeError::new_err("Path does not exist for fill"))?
            .detach();
        let mut paint = self.paint.clone();
        paint.set_stroke(false);
        paint.set_anti_alias(true);
        self.skia_surface.canvas().draw_path(&path, &paint);
        Ok(())
    }

    fn add_color_stop_rgba(&mut self, offset: f32, r: f32, g: f32, b: f32, a: f32) {
        self.gradient_offsets.push(offset);
        self.gradient_colors.push(Color4f::new(r, g, b, a));
    }

    fn set_source_linear_gradient(&mut self, x0: f32, y0: f32, x1: f32, y1: f32) -> PyResult<()> {
        let gradient = gradient::Gradient::new(
            gradient::Colors::new(
                &self.gradient_colors,
                Some(&self.gradient_offsets),
                TileMode::Clamp,
                None,
            ),
            gradient::Interpolation::default(),
        );
        let shader = gradient::shaders::linear_gradient(
            (Point::new(x0, y0), Point::new(x1, y1)),
            &gradient,
            None,
        )
        .ok_or(PyRuntimeError::new_err(
            "Issue with creating linear gradient shader (did you add color stops?)",
        ))?;
        self.paint.set_shader(shader);
        Ok(())
    }

    fn set_source_radial_gradient(&mut self, xc: f32, yc: f32, radius: f32) -> PyResult<()> {
        let gradient = gradient::Gradient::new(
            gradient::Colors::new(
                &self.gradient_colors,
                Some(&self.gradient_offsets),
                TileMode::Clamp,
                None,
            ),
            gradient::Interpolation::default(),
        );
        let shader =
            gradient::shaders::radial_gradient((Point::new(xc, yc), radius), &gradient, None)
                .ok_or(PyRuntimeError::new_err(
                    "Issue with creating radial gradient shader (did you add color stops?)",
                ))?;
        self.paint.set_shader(shader);
        Ok(())
    }

    fn set_source_gradient(&mut self, g: Gradient) -> PyResult<()> {
        match g {
            Gradient::LinearGradient(x0, y0, x1, y1) => {
                self.set_source_linear_gradient(x0, y0, x1, y1)?
            }
            Gradient::RadialGradient(xc, yc, radius) => {
                self.set_source_radial_gradient(xc, yc, radius)?
            }
        }
        self.gradient_offsets.clear();
        self.gradient_colors.clear();
        Ok(())
    }

    fn draw_image(&mut self, image: &WyvernImage, x: f32, y: f32, a: f32) {
        let mut paint = Paint::default();
        paint.set_alpha_f(a);
        paint.set_anti_alias(true);
        self.skia_surface.canvas().draw_image_with_sampling_options(
            &image.image,
            Point::new(x, y),
            skia_safe::SamplingOptions::new(
                skia_safe::FilterMode::Linear,
                skia_safe::MipmapMode::None,
            ),
            Some(&paint),
        );
    }

    fn resize_canvas(&mut self, width: i32, height: i32, scale_factor: f64) -> PyResult<()> {
        self.skia_surface = create_skia_surface(width, height, scale_factor)?;
        self.path = None;
        self.state_stack.clear();
        Ok(())
    }

    fn save_png(&mut self, path: String) -> PyResult<()> {
        let image = self.skia_surface.image_snapshot();
        let data = image
            .encode(None, skia_safe::EncodedImageFormat::PNG, 100)
            .ok_or(PyRuntimeError::new_err("Failed to encode image data"))?;
        let mut file = File::create(path)?;
        file.write_all(data.as_bytes())?;
        Ok(())
    }
}

fn create_image(data: skia_safe::Data) -> PyResult<WyvernImage> {
    let image =
        Image::from_encoded(&data).ok_or(PyRuntimeError::new_err("Unsupported image format"))?;

    // Whether the pixels are known to be opaque, from the decoded image's
    // alpha type (e.g. JPEG)
    let opaque = image.is_opaque();

    let bounds = image.bounds();

    Ok(WyvernImage {
        image,
        width: bounds.width(),
        height: bounds.height(),
        opaque,
    })
}

#[pyfunction]
fn load_image_from_path(path: &str) -> PyResult<WyvernImage> {
    let mut file = File::open(path)?;
    let mut bytes = Vec::new();
    file.read_to_end(&mut bytes)?;
    let skia_data = skia_safe::Data::new_copy(&bytes);

    create_image(skia_data)
}

#[pyfunction]
fn load_image_from_bytes(py_bytes: &Bound<'_, PyBytes>) -> PyResult<WyvernImage> {
    let skia_data = skia_safe::Data::new_copy(py_bytes.as_bytes());
    create_image(skia_data)
}

#[pyclass(module = "wyvern", subclass)]
struct ImageSurface {
    width: i32,
    height: i32,
    canvas: Py<Canvas>,
}

#[pymethods]
impl ImageSurface {
    #[new]
    #[pyo3(signature = (width, height, scale_factor = 1.0))]
    fn create(width: i32, height: i32, scale_factor: f64) -> PyResult<Self> {
        Python::attach(|py| {
            let skia_surface = create_skia_surface(width, height, scale_factor)?;
            let font_mgr = FontMgr::new();
            let style = FontStyle::new(
                font_style::Weight::NORMAL,
                font_style::Width::NORMAL,
                font_style::Slant::Upright,
            );
            let arial = get_arial(&font_mgr, style)?;
            let canvas = Py::new(
                py,
                Canvas {
                    skia_surface,
                    path: None,
                    font_mgr,
                    font: Font::from_typeface(arial, 12.0),
                    gradient_colors: Vec::new(),
                    gradient_offsets: Vec::new(),
                    paint: Paint::default(),
                    state_stack: Vec::new(),
                },
            )?;
            Ok(ImageSurface {
                width,
                height,
                canvas,
            })
        })
    }

    #[getter]
    fn width(&self) -> i32 {
        self.width
    }

    #[getter]
    fn height(&self) -> i32 {
        self.height
    }

    #[getter]
    fn canvas(&self, py: Python<'_>) -> Py<Canvas> {
        self.canvas.clone_ref(py)
    }

    #[setter]
    fn set_width(&mut self, width: i32) {
        self.width = width;
    }

    #[setter]
    fn set_height(&mut self, height: i32) {
        self.height = height;
    }
}
/* WYVERN */

/* BYEGAME */
use rodio::{Decoder, DeviceSinkBuilder, MixerDeviceSink, Player, Source};
use std::io::Cursor;
use std::num::NonZero;
use std::rc::Rc;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, OnceLock};
use std::time::{Duration, Instant};
use winit::application::ApplicationHandler;
use winit::dpi::{LogicalSize, PhysicalPosition, PhysicalSize};
use winit::event::{DeviceId, ElementState, Modifiers, MouseButton, WindowEvent};
use winit::event_loop::{ActiveEventLoop, ControlFlow, EventLoop, EventLoopProxy};
use winit::keyboard::{Key, NamedKey, PhysicalKey};
use std::collections::HashMap;
use winit::window::{Window, WindowAttributes, WindowId};

fn get_stream() -> PyResult<&'static MixerDeviceSink> {
    static STREAM: OnceLock<MixerDeviceSink> = OnceLock::new();

    if let Some(stream) = STREAM.get() {
        return Ok(stream);
    }

    let stream = DeviceSinkBuilder::open_default_sink()
        .map_err(|e| PyRuntimeError::new_err(format!("Failed to open audio output: {e}")))?;

    Ok(STREAM.get_or_init(|| stream))
}

#[pyclass(module = "wyvern")]
struct WyvernSound {
    // Shared with each playback's decoder, so playing doesn't copy the data
    data: Arc<[u8]>,
    sink: Option<Player>,
    volume: f32,
}

impl WyvernSound {
    fn start_new(&mut self, looped: bool) -> PyResult<()> {
        let stream = get_stream()?;
        let player = Player::connect_new(stream.mixer());
        let cursor = Cursor::new(Arc::clone(&self.data));
        let source = Decoder::try_from(cursor)
            .map_err(|e| PyRuntimeError::new_err(format!("Failed to decode sound data: {e}")))?;

        player.set_volume(self.volume);

        if looped {
            player.append(source.repeat_infinite());
        } else {
            player.append(source);
        }

        self.sink = Some(player);

        Ok(())
    }
}

#[pymethods]
impl WyvernSound {
    #[new]
    fn create(bytes: &Bound<'_, PyBytes>) -> PyResult<Self> {
        let data: Arc<[u8]> = Arc::from(bytes.as_bytes());
        // Decode now, so unsupported data fails when the Sound is created
        // rather than on the first play()
        Decoder::try_from(Cursor::new(Arc::clone(&data)))
            .map_err(|e| PyRuntimeError::new_err(format!("Failed to decode sound data: {e}")))?;
        Ok(WyvernSound {
            data,
            sink: None,
            volume: 1.0,
        })
    }

    #[pyo3(signature = (looped = false, restart = false))]
    fn play(&mut self, looped: bool, restart: bool) -> PyResult<()> {
        let is_busy = self.sink.as_ref().map(|s| !s.empty()).unwrap_or(false);
        if !is_busy {
            self.start_new(looped)?;
        } else if restart {
            if let Some(player) = self.sink.take() {
                player.stop();
            }
            self.start_new(looped)?;
        } else if let Some(player) = &self.sink {
            player.play();
        }
        Ok(())
    }

    fn pause(&self) {
        if let Some(player) = &self.sink {
            player.pause();
        }
    }

    fn set_volume(&mut self, volume: f32) {
        if volume < 0.0 {
            return;
        }
        self.volume = volume.min(1.0);
        if let Some(player) = &self.sink {
            player.set_volume(self.volume);
        }
    }

    fn get_volume(&self) -> f32 {
        self.volume
    }
}

impl Drop for WyvernSound {
    // Dropping a Player stops its sound, but a sound should keep playing
    // after its Sound is garbage collected, as with Sound(url).play().
    // Detaching lets it play to the end (or loop forever).
    fn drop(&mut self) {
        if let Some(player) = self.sink.take() {
            player.detach();
        }
    }
}

enum UserEvent {
    Quit,
    SetActiveScreen(String),
    CursorVisible(bool),
    Fullscreen(bool),
    SetSize(u32, u32),
    Inject(InjectedEvent),
}

// Synthetic window events for tests, in logical coordinates. They go through
// the same window_event handling as real OS input.
enum InjectedEvent {
    MouseMove(f64, f64),
    MouseButton(u8, bool),
    Resize(u32, u32),
}

// Mouse motion is throttled to roughly 30 events per second.
// The latest position is held back and sent once the throttle
// window passes, so the final position is never dropped.
const MOUSE_THROTTLE: Duration = Duration::from_nanos(1_000_000_000 / 30);

// Time between step events, in nanoseconds. 0 means steps are disabled.
// Python updates this whenever app.stepsPerSecond changes, including before
// the event loop starts, so it's a global rather than a UserEvent.
static STEP_INTERVAL_NANOS: AtomicU64 = AtomicU64::new(1_000_000_000 / 30);

fn step_interval() -> Option<Duration> {
    match STEP_INTERVAL_NANOS.load(Ordering::Relaxed) {
        0 => None,
        nanos => Some(Duration::from_nanos(nanos)),
    }
}

// apparently this is idiomatic
static PROXY: OnceLock<EventLoopProxy<UserEvent>> = OnceLock::new();

struct AppInternals {
    window: Rc<Window>,
    softbuffer_surface: softbuffer::Surface<Rc<Window>, Rc<Window>>,
}

struct WinitApp {
    window_attributes: WindowAttributes,
    internals: Option<AppInternals>,
    last_tick: Instant,
    last_mouse: Instant,
    mouse_pending: bool,
    pressed_buttons: Vec<u8>,
    cursor_position: PhysicalPosition<f64>,
    cursor_visible: bool,
    py_surface: Option<Py<ImageSurface>>,
    on_event: Py<PyAny>,
    modifiers: Modifiers,
    pressed_keys: HashMap<PhysicalKey, (String, bool)>,
    error: Option<PyErr>,
    fullscreen: bool,
    // False for a hidden window: never shown or focused, as when running
    // tests. Redraws are then run from the event loop instead of waiting for
    // the OS to paint the window, which it won't do for a hidden one.
    visible: bool,
    redraw_pending: bool,
}

#[pyclass(from_py_object)]
#[derive(Clone)]
pub struct MouseEvent {
    #[pyo3(get)]
    pub x: i32,
    #[pyo3(get)]
    pub y: i32,
    #[pyo3(get)]
    pub button: u8,
    // All buttons currently held down, for drag events
    #[pyo3(get)]
    pub buttons: Vec<u8>,
}

fn winit_button_to_int(button: winit::event::MouseButton) -> Option<u8> {
    match button {
        winit::event::MouseButton::Left => Some(0),
        winit::event::MouseButton::Middle => Some(1),
        winit::event::MouseButton::Right => Some(2),
        _ => None,
    }
}

fn to_logical_pixels(position: PhysicalPosition<f64>, scale: f64) -> (i32, i32) {
    (
        (position.x / scale).floor() as i32,
        (position.y / scale).floor() as i32,
    )
}

#[pyclass(from_py_object)]
#[derive(Clone)]
pub struct KeyEvent {
    #[pyo3(get)]
    pub key: String,
    #[pyo3(get)]
    pub is_named: bool,
    #[pyo3(get)]
    pub modifiers: Vec<String>,
}

// The name the app sees for a named (non-character) key. This matches the web
// version, which lowercases the browser's key name: winit's NamedKey variants
// are the same W3C key names, so "PageUp" becomes "pageup" and "F1" becomes
// "f1". Arrow keys drop the "arrow", so "ArrowLeft" becomes "left".
fn named_key_name(name: &NamedKey) -> Option<String> {
    match name {
        // Modifier keys only change other keys, so the app doesn't see them,
        // like the web version. Control is the exception: the framework uses
        // it for the inspector, and doesn't pass it on to the app either.
        NamedKey::Shift
        | NamedKey::Alt
        | NamedKey::Super
        | NamedKey::Meta
        | NamedKey::Hyper
        | NamedKey::CapsLock => None,
        _ => {
            let name = format!("{name:?}").to_lowercase();
            Some(match name.strip_prefix("arrow") {
                Some(direction) => direction.to_string(),
                None => name,
            })
        }
    }
}

// The key name and is_named for a key event, or None for keys the app
// doesn't see
fn key_name(key: &Key) -> Option<(String, bool)> {
    match key {
        Key::Character(s) => Some((s.to_string(), false)),
        Key::Named(name) => named_key_name(name).map(|name| (name, true)),
        _ => None,
    }
}

fn modifiers_to_vec(modifiers: &winit::event::Modifiers) -> Vec<String> {
    let mut result = Vec::new();
    let state = modifiers.state();
    if state.shift_key() {
        result.push("shift".to_string());
    }
    if state.control_key() {
        result.push("control".to_string());
    }
    // "meta" is Cmd on macOS and the Windows key on Windows, as it is
    // in the web version. Alt isn't reported.
    if state.super_key() {
        result.push("meta".to_string());
    }
    result
}

#[pyclass(from_py_object)]
#[derive(Clone)]
pub struct ResizeEvent {
    #[pyo3(get)]
    pub width: u32,
    #[pyo3(get)]
    pub height: u32,
}

#[pyclass(from_py_object)]
#[derive(Clone)]
pub struct PythonEvent {
    #[pyo3(get)]
    pub event_type: String,
    #[pyo3(get)]
    pub mouse: Option<MouseEvent>,
    #[pyo3(get)]
    pub key: Option<KeyEvent>,
    #[pyo3(get)]
    pub resize: Option<ResizeEvent>,
    #[pyo3(get)]
    pub new_screen: Option<String>,
    #[pyo3(get)]
    pub modifiers: Option<Vec<String>>,
}

impl PythonEvent {
    pub fn mouse_press(x: i32, y: i32, button: u8) -> Self {
        PythonEvent {
            event_type: "mouse_press".to_string(),
            mouse: Some(MouseEvent {
                x,
                y,
                button,
                buttons: Vec::new(),
            }),
            key: None,
            resize: None,
            new_screen: None,
            modifiers: None,
        }
    }

    pub fn mouse_release(x: i32, y: i32, button: u8) -> Self {
        PythonEvent {
            event_type: "mouse_release".to_string(),
            mouse: Some(MouseEvent {
                x,
                y,
                button,
                buttons: Vec::new(),
            }),
            key: None,
            resize: None,
            new_screen: None,
            modifiers: None,
        }
    }

    pub fn mouse_move(x: i32, y: i32) -> Self {
        PythonEvent {
            event_type: "mouse_move".to_string(),
            mouse: Some(MouseEvent {
                x,
                y,
                button: 0,
                buttons: Vec::new(),
            }),
            key: None,
            resize: None,
            new_screen: None,
            modifiers: None,
        }
    }

    pub fn mouse_drag(x: i32, y: i32, buttons: Vec<u8>) -> Self {
        PythonEvent {
            event_type: "mouse_drag".to_string(),
            mouse: Some(MouseEvent {
                x,
                y,
                button: buttons.first().copied().unwrap_or(0),
                buttons,
            }),
            key: None,
            resize: None,
            new_screen: None,
            modifiers: None,
        }
    }

    pub fn key_press(key: String, is_named: bool, modifiers: Vec<String>) -> Self {
        PythonEvent {
            event_type: "key_press".to_string(),
            mouse: None,
            key: Some(KeyEvent {
                key,
                is_named,
                modifiers,
            }),
            resize: None,
            new_screen: None,
            modifiers: None,
        }
    }

    pub fn key_release(key: String, is_named: bool, modifiers: Vec<String>) -> Self {
        PythonEvent {
            event_type: "key_release".to_string(),
            mouse: None,
            key: Some(KeyEvent {
                key,
                is_named,
                modifiers,
            }),
            resize: None,
            new_screen: None,
            modifiers: None,
        }
    }

    pub fn resize(width: u32, height: u32) -> Self {
        PythonEvent {
            event_type: "resize".to_string(),
            mouse: None,
            key: None,
            resize: Some(ResizeEvent { width, height }),
            new_screen: None,
            modifiers: None,
        }
    }

    pub fn quit() -> Self {
        PythonEvent {
            event_type: "quit".to_string(),
            mouse: None,
            key: None,
            resize: None,
            new_screen: None,
            modifiers: None,
        }
    }

    pub fn step() -> Self {
        PythonEvent {
            event_type: "step".to_string(),
            mouse: None,
            key: None,
            resize: None,
            new_screen: None,
            modifiers: None,
        }
    }

    pub fn redraw() -> Self {
        PythonEvent {
            event_type: "redraw".to_string(),
            mouse: None,
            key: None,
            resize: None,
            new_screen: None,
            modifiers: None,
        }
    }

    // Sent when only modifier keys change, since those keys don't send key
    // events, so onKeyHold sees the current modifiers
    pub fn modifiers_changed(modifiers: Vec<String>) -> Self {
        PythonEvent {
            event_type: "modifiers_changed".to_string(),
            mouse: None,
            key: None,
            resize: None,
            new_screen: None,
            modifiers: Some(modifiers),
        }
    }

    pub fn set_active_screen(new_screen: String) -> Self {
        PythonEvent {
            event_type: "set_active_screen".to_string(),
            mouse: None,
            key: None,
            resize: None,
            new_screen: Some(new_screen),
            modifiers: None,
        }
    }
}

impl WinitApp {
    // Sends an event to Python, then asks for a redraw so its effects show up.
    fn call_event_handler(&mut self, event_loop: &ActiveEventLoop, event: PythonEvent) {
        if !self.dispatch(event_loop, event) {
            return;
        }
        self.request_redraw(event_loop);
    }

    fn request_redraw(&mut self, event_loop: &ActiveEventLoop) {
        if !self.visible {
            // Run from about_to_wait, after the current events
            self.redraw_pending = true;
            return;
        }
        if let Some(internals) = self.internals.as_ref() {
            internals.window.request_redraw()
        } else {
            self.error = Some(PyRuntimeError::new_err("Issue with redrawing window"));
            event_loop.exit();
        }
    }

    // Sends an event to Python without requesting a redraw. Returns whether
    // the handler succeeded.
    fn dispatch(&mut self, event_loop: &ActiveEventLoop, event: PythonEvent) -> bool {
        let handler_result = Python::attach(|py| -> PyResult<()> {
            let Some(py_surface) = self.py_surface.as_ref() else {
                self.error = Some(PyRuntimeError::new_err(
                    "Surface does not exist for event handler",
                ));
                event_loop.exit();
                return Ok(());
            };
            self.on_event.call1(py, (event, py_surface.clone_ref(py)))?;
            Ok(())
        });

        if let Err(err) = handler_result {
            self.error = Some(err);
            event_loop.exit();
            return false;
        };
        self.error.is_none()
    }

    // Sends the current cursor position as a move or drag event.
    fn send_mouse_motion(&mut self, event_loop: &ActiveEventLoop) {
        let Some(app_internals) = self.internals.as_ref() else {
            return;
        };
        let (x, y) =
            to_logical_pixels(self.cursor_position, app_internals.window.scale_factor());
        let event = if self.pressed_buttons.is_empty() {
            PythonEvent::mouse_move(x, y)
        } else {
            PythonEvent::mouse_drag(x, y, self.pressed_buttons.clone())
        };
        self.mouse_pending = false;
        self.last_mouse = Instant::now();
        self.call_event_handler(event_loop, event);
    }

    fn handle_resize(&mut self, event_loop: &ActiveEventLoop, new_size: PhysicalSize<u32>) {
        let Some(app_internals) = self.internals.as_mut() else {
            return;
        };
        let Some(py_surface) = self.py_surface.as_ref() else {
            return;
        };
        // Windows reports a size of 0x0 when the window is minimized. Keep
        // the current surfaces; a real Resized follows when it's restored.
        let (Some(new_width), Some(new_height)) =
            (NonZero::new(new_size.width), NonZero::new(new_size.height))
        else {
            return;
        };

        if app_internals
            .softbuffer_surface
            .resize(new_width, new_height)
            .is_err()
        {
            self.error = Some(PyRuntimeError::new_err(
                "Issue with resizing softbuffer surface",
            ));
            event_loop.exit();
            return;
        };

        let scale_factor = app_internals.window.scale_factor();
        let resize_result = Python::attach(|py| -> PyResult<()> {
            let mut surface_ref = py_surface.borrow_mut(py);
            let mut canvas = surface_ref.canvas.bind(py).borrow_mut();
            canvas.resize_canvas(new_size.width as i32, new_size.height as i32, scale_factor)?;
            surface_ref.width = new_size.width as i32;
            surface_ref.height = new_size.height as i32;
            Ok(())
        });
        if let Err(err) = resize_result {
            self.error = Some(err);
            event_loop.exit();
            return;
        }

        let logical_size: LogicalSize<u32> = new_size.to_logical(scale_factor);
        self.call_event_handler(
            event_loop,
            PythonEvent::resize(logical_size.width, logical_size.height),
        );
    }

    // Draws the app to its canvas, and shows the canvas in the window
    fn redraw(&mut self, event_loop: &ActiveEventLoop) {
        // Don't request another redraw here, or we'd redraw forever
        if !self.dispatch(event_loop, PythonEvent::redraw()) {
            return;
        }
        // A hidden window's canvas is only used for screenshots
        if !self.visible {
            return;
        }

        let Some(app_internals) = self.internals.as_mut() else {
            return;
        };
        let Some(py_surface) = self.py_surface.as_mut() else {
            return;
        };

        let Ok(mut buffer) = app_internals.softbuffer_surface.buffer_mut() else {
            self.error = Some(PyRuntimeError::new_err(
                "Issue with obtaining softbuffer surface",
            ));
            event_loop.exit();
            return;
        };
        let result = Python::attach(|py| -> PyResult<()> {
            let surface_ref = py_surface.borrow(py);
            let mut canvas_ref = surface_ref.canvas.bind(py).borrow_mut();
            let pixmap = canvas_ref
                .skia_surface
                .peek_pixels()
                .ok_or_else(|| PyRuntimeError::new_err("Issue getting canvas data"))?;

            let bytes = pixmap.bytes().ok_or_else(|| {
                PyRuntimeError::new_err("Issue getting bytes from pixel data")
            })?;
            let safe_len = buffer.len().min(bytes.len() / 4);
            for (i, pixel) in buffer.iter_mut().take(safe_len).enumerate() {
                let offset = i * 4;
                let r = bytes[offset] as u32;
                let g = bytes[offset + 1] as u32;
                let b = bytes[offset + 2] as u32;
                *pixel = (r << 16) | (g << 8) | b;
            }
            if safe_len < buffer.len() {
                return Ok(());
            }
            if buffer.present().is_err() {
                return Err(PyRuntimeError::new_err("Issue presenting to buffer"));
            }
            Ok(())
        });

        if let Err(err) = result {
            self.error = Some(err);
            event_loop.exit();
        }
    }

    fn apply_window_state(&self) {
        // Going fullscreen would show a hidden window
        if !self.visible {
            return;
        }
        let Some(internals) = self.internals.as_ref() else {
            return;
        };
        internals.window.set_cursor_visible(self.cursor_visible);
        let fullscreen = if self.fullscreen {
            Some(Borderless(None))
        } else {
            None
        };
        if internals.window.fullscreen() != fullscreen {
            internals.window.set_fullscreen(fullscreen);
        }
    }
}

impl ApplicationHandler<UserEvent> for WinitApp {
    fn resumed(&mut self, event_loop: &ActiveEventLoop) {
        let window = if let Ok(window) = event_loop.create_window(self.window_attributes.clone()) {
            // make the window centered
            if let Some(monitor) = window.current_monitor() {
                let screen_size = monitor.size();
                let window_size = window.outer_size();

                let x = (screen_size.width.saturating_sub(window_size.width) / 2) as i32
                    + monitor.position().x;
                let y = (screen_size.height.saturating_sub(window_size.height) / 2) as i32
                    + monitor.position().y;

                window.set_outer_position(PhysicalPosition::new(x, y));
            }
            #[cfg(target_os = "macos")]
            disable_window_restoration(&window);
            Rc::new(window)
        } else {
            self.error = Some(PyRuntimeError::new_err("Issue with creating window"));
            event_loop.exit();
            return;
        };
        let softbuffer_surface = {
            let Ok(context) = softbuffer::Context::new(window.clone()) else {
                self.error = Some(PyRuntimeError::new_err(
                    "Issue with creating context for softbuffer surface",
                ));
                event_loop.exit();
                return;
            };
            let Ok(surface) = softbuffer::Surface::new(&context, window.clone()) else {
                self.error = Some(PyRuntimeError::new_err(
                    "Issue with creating softbuffer surface",
                ));
                event_loop.exit();
                return;
            };
            surface
        };

        let scale_factor = window.scale_factor();
        let (phys_width, phys_height) = {
            let size = window.inner_size();
            (size.width, size.height)
        };
        let py_surface = ImageSurface::create(phys_width as i32, phys_height as i32, scale_factor);

        if let Err(err) = Python::attach(|py| -> PyResult<()> {
            let py_surface = Py::new(py, py_surface?)?;
            self.py_surface = Some(py_surface);
            Ok(())
        }) {
            self.error = Some(err);
            event_loop.exit();
            return;
        };

        if self.visible {
            window.set_visible(true);
        }

        self.internals = Some(AppInternals {
            window,
            softbuffer_surface,
        });
        self.apply_window_state();
        // A hidden window's app has no Dock icon
        #[cfg(target_os = "macos")]
        if self.visible {
            set_dock_icon();
        }
        self.request_redraw(event_loop);
    }

    fn about_to_wait(&mut self, event_loop: &ActiveEventLoop) {
        if self.internals.is_none() || event_loop.exiting() {
            return;
        }

        // None if steps are off, or so far apart that the time overflows
        let interval = step_interval().filter(|i| self.last_tick.checked_add(*i).is_some());
        if let Some(interval) = interval {
            let due = self.last_tick + interval;
            let now = Instant::now();
            if now >= due {
                // Keep steps on their schedule, unless we've fallen more than
                // a whole step behind, in which case don't try to catch up.
                self.last_tick = if now - due < interval { due } else { now };
                self.call_event_handler(event_loop, PythonEvent::step());
            }
        }

        if self.mouse_pending && self.last_mouse.elapsed() >= MOUSE_THROTTLE {
            self.send_mouse_motion(event_loop);
        }

        if self.redraw_pending && !event_loop.exiting() {
            self.redraw_pending = false;
            self.redraw(event_loop);
        }

        // Sleep until the next step or held-back mouse event is due, instead
        // of spinning. Window and user events wake the loop early.
        let mut wake: Option<Instant> = interval.and_then(|i| self.last_tick.checked_add(i));
        if self.mouse_pending {
            let mouse_due = self.last_mouse + MOUSE_THROTTLE;
            wake = Some(wake.map_or(mouse_due, |w| w.min(mouse_due)));
        }
        event_loop.set_control_flow(match wake {
            Some(instant) => ControlFlow::WaitUntil(instant),
            None => ControlFlow::Wait,
        });
    }

    fn window_event(&mut self, event_loop: &ActiveEventLoop, _id: WindowId, event: WindowEvent) {
        match event {
            WindowEvent::CloseRequested => {
                event_loop.exit();
            }
            WindowEvent::Resized(new_size) => {
                self.handle_resize(event_loop, new_size);
            }
            WindowEvent::CursorMoved {
                device_id: _,
                position,
            } => {
                // Always track the position, so clicks use where the cursor
                // really is even when the motion event itself is held back.
                self.cursor_position = position;
                if self.last_mouse.elapsed() < MOUSE_THROTTLE {
                    self.mouse_pending = true;
                    return;
                }
                self.send_mouse_motion(event_loop);
            }
            WindowEvent::MouseInput {
                device_id: _,
                state,
                button,
            } => {
                let Some(button_int) = winit_button_to_int(button) else {
                    return;
                };
                // Deliver any held-back motion first, so handlers see events
                // in the order they happened.
                if self.mouse_pending {
                    self.send_mouse_motion(event_loop);
                }
                let Some(app_internals) = self.internals.as_ref() else {
                    return;
                };
                let (x, y) =
                    to_logical_pixels(self.cursor_position, app_internals.window.scale_factor());
                match state {
                    winit::event::ElementState::Pressed => {
                        if !self.pressed_buttons.contains(&button_int) {
                            self.pressed_buttons.push(button_int);
                            self.pressed_buttons.sort_unstable();
                        }
                        self.call_event_handler(
                            event_loop,
                            PythonEvent::mouse_press(x, y, button_int),
                        );
                    }
                    winit::event::ElementState::Released => {
                        self.pressed_buttons.retain(|&b| b != button_int);
                        self.call_event_handler(
                            event_loop,
                            PythonEvent::mouse_release(x, y, button_int),
                        );
                    }
                }
            }
            WindowEvent::RedrawRequested => {
                self.redraw(event_loop);
            }
            WindowEvent::KeyboardInput {
                device_id: _,
                event,
                is_synthetic,
            } => {
                // A held key sends one press; apps use onKeyHold for repeated behavior.
                // Synthetic events (Windows and X11 only) are skipped, since held keys are
                // released on Focused(false) instead, on every platform.
                if is_synthetic || event.repeat {
                    return;
                }
                match event.state {
                    winit::event::ElementState::Pressed => {
                        let Some((key, is_named)) = key_name(&event.logical_key) else {
                            return;
                        };
                        self.pressed_keys
                            .insert(event.physical_key, (key.clone(), is_named));
                        self.call_event_handler(
                            event_loop,
                            PythonEvent::key_press(
                                key,
                                is_named,
                                modifiers_to_vec(&self.modifiers),
                            ),
                        );
                    }
                    winit::event::ElementState::Released => {
                        let released = match self.pressed_keys.remove(&event.physical_key) {
                            Some(pressed) => pressed,
                            // Pressed before the window had focus
                            None => {
                                let Some(released) = key_name(&event.logical_key) else {
                                    return;
                                };
                                released
                            }
                        };
                        let (key, is_named) = released;
                        self.call_event_handler(
                            event_loop,
                            PythonEvent::key_release(
                                key,
                                is_named,
                                modifiers_to_vec(&self.modifiers),
                            ),
                        );
                    }
                }
            }
            WindowEvent::Focused(false) => {
                // The window won't see the releases of keys that are down
                // now, e.g. after alt-tabbing away or when getTextInput's
                // window opens, so release them now.
                // Otherwise onKeyHold would keep reporting them.
                let held: Vec<(String, bool)> =
                    self.pressed_keys.drain().map(|(_, pressed)| pressed).collect();
                for (key, is_named) in held {
                    if event_loop.exiting() {
                        break;
                    }
                    self.call_event_handler(
                        event_loop,
                        PythonEvent::key_release(
                            key,
                            is_named,
                            modifiers_to_vec(&self.modifiers),
                        ),
                    );
                }
            }
            WindowEvent::ModifiersChanged(new_modifiers) => {
                self.modifiers = new_modifiers;
                // Nothing to redraw, since only the modifiers changed
                self.dispatch(
                    event_loop,
                    PythonEvent::modifiers_changed(modifiers_to_vec(&self.modifiers)),
                );
            }
            _ => (),
        }
    }

    fn user_event(&mut self, event_loop: &ActiveEventLoop, event: UserEvent) {
        match event {
            UserEvent::Quit => {
                self.call_event_handler(event_loop, PythonEvent::quit());
                event_loop.exit()
            }
            UserEvent::SetActiveScreen(screen) => {
                self.call_event_handler(event_loop, PythonEvent::set_active_screen(screen));
            }
            UserEvent::CursorVisible(visible) => {
                self.cursor_visible = visible;
                self.apply_window_state();
            }
            UserEvent::Fullscreen(fullscreen) => {
                self.fullscreen = fullscreen;
                self.apply_window_state();
            }
            UserEvent::Inject(injected) => {
                let Some(internals) = self.internals.as_ref() else {
                    return;
                };
                let window_id = internals.window.id();
                let scale = internals.window.scale_factor();
                let window_event = match injected {
                    InjectedEvent::MouseMove(x, y) => WindowEvent::CursorMoved {
                        device_id: DeviceId::dummy(),
                        position: PhysicalPosition::new(x * scale, y * scale),
                    },
                    InjectedEvent::MouseButton(button, pressed) => WindowEvent::MouseInput {
                        device_id: DeviceId::dummy(),
                        state: if pressed {
                            ElementState::Pressed
                        } else {
                            ElementState::Released
                        },
                        button: match button {
                            1 => MouseButton::Middle,
                            2 => MouseButton::Right,
                            _ => MouseButton::Left,
                        },
                    },
                    InjectedEvent::Resize(width, height) => {
                        WindowEvent::Resized(LogicalSize::new(width, height).to_physical(scale))
                    }
                };
                self.window_event(event_loop, window_id, window_event);
            }
            UserEvent::SetSize(width, height) => {
                let Some(internals) = self.internals.as_ref() else {
                    return;
                };
                // If the size is applied immediately, winit may not send
                // Resized, so handle it here too
                if let Some(new_size) = internals
                    .window
                    .request_inner_size(LogicalSize::new(width.max(1), height.max(1)))
                {
                    self.handle_resize(event_loop, new_size);
                }
            }
        }
    }
}

// The Scotty icon, shown for the window (Linux) and in the Dock (macOS)
#[cfg(not(target_os = "windows"))]
const ICON_PNG: &[u8] = include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/scotty.png"));

// Windows shrinks the icon to fit a small square (16-32px in the title bar and
// taskbar), and scotty.png's transparent margin made Scotty look tiny there.
// This copy is cropped so Scotty fills about 85% of its height, and is
// 256x256, the largest size winit suggests for the taskbar icon.
#[cfg(target_os = "windows")]
const ICON_PNG: &[u8] = include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/scotty_256.png"));

// On Windows, the window icon only sets the small (title bar) icon. The
// taskbar uses the big icon, and without one it shows python.exe's icon.
// None (no taskbar icon, so the app still runs) if the image can't be used
#[cfg(target_os = "windows")]
fn taskbar_icon() -> Option<winit::window::Icon> {
    let image = image::load_from_memory(ICON_PNG).ok()?.into_rgba8();
    let (width, height) = image.dimensions();
    winit::window::Icon::from_rgba(image.into_raw(), width, height).ok()
}

// The taskbar groups windows by app ID, and a process without one is grouped
// as python.exe, so the taskbar shows Python's icon instead of the window's.
// Giving the process its own ID fixes that (and keeps cmu_graphics windows out
// of IDLE's group). It only affects windows created afterward, so call it
// before creating the window. Keep the ID stable: changing it splits taskbar
// grouping and pins between versions.
#[cfg(target_os = "windows")]
fn set_app_user_model_id() {
    use windows_sys::Win32::UI::Shell::SetCurrentProcessExplicitAppUserModelID;
    // Safety: w! makes a static, null-terminated UTF-16 string. Failure only
    // means the taskbar keeps Python's icon, so the result is ignored.
    let _ = unsafe {
        SetCurrentProcessExplicitAppUserModelID(windows_sys::w!("CMU.CSAcademy.CMUGraphics"))
    };
}

// macOS has no per-window icons, so winit ignores the window icon there; the
// Dock shows the application's icon instead, which would otherwise be
// Python's. Must be called on the main thread, after the event loop exists.
#[cfg(target_os = "macos")]
fn set_dock_icon() {
    use objc2::ClassType;
    use objc2_app_kit::{NSApplication, NSImage};
    use objc2_foundation::{MainThreadMarker, NSData};

    let Some(mtm) = MainThreadMarker::new() else {
        return;
    };
    let data = NSData::with_bytes(ICON_PNG);
    let Some(image) = NSImage::initWithData(NSImage::alloc(), &data) else {
        return;
    };
    let app = NSApplication::sharedApplication(mtm);
    // Safety: called on the main thread, with a valid image
    unsafe { app.setApplicationIconImage(Some(&image)) };
}

// macOS window restoration. Every program run with the same Python shares one
// saved state, so without these, programs running at once restore each
// other's windows, and after a program crashes soon after starting, the next
// one asks whether to reopen windows -- a prompt that a hidden window (as in
// the tests) never answers.
//
// ignore_saved_window_state keeps AppKit from restoring any saved state when
// the event loop starts. ApplePersistenceIgnoreStateQuietly is the variant of
// ApplePersistenceIgnoreState that doesn't log a message on every launch. It
// goes in the registration domain, which only lasts as long as the process and
// yields to any explicit setting.
#[cfg(target_os = "macos")]
fn ignore_saved_window_state() {
    use objc2::rc::Retained;
    use objc2::runtime::AnyObject;
    use objc2_foundation::{NSDictionary, NSNumber, NSString, NSUserDefaults};

    let key = NSString::from_str("ApplePersistenceIgnoreStateQuietly");
    let value: Retained<AnyObject> = Retained::into_super(Retained::into_super(
        Retained::into_super(NSNumber::new_bool(true)),
    ));
    let defaults = NSDictionary::from_vec(&[&*key], vec![value]);
    // Safety: the dictionary holds only property-list objects
    unsafe { NSUserDefaults::standardUserDefaults().registerDefaults(&defaults) };
}

// disable_window_restoration keeps this window out of the saved state.
#[cfg(target_os = "macos")]
fn disable_window_restoration(window: &Window) {
    use objc2_app_kit::NSView;
    use winit::raw_window_handle::{HasWindowHandle, RawWindowHandle};

    let Ok(handle) = window.window_handle() else {
        return;
    };
    let RawWindowHandle::AppKit(handle) = handle.as_raw() else {
        return;
    };
    // Safety: winit's AppKit handle points at the window's live NSView, and
    // this runs on the main thread, where winit creates windows
    let view: &NSView = unsafe { handle.ns_view.cast().as_ref() };
    if let Some(ns_window) = view.window() {
        // Safety: called on the main thread, on a valid window
        unsafe { ns_window.setRestorable(false) };
    }
}

#[pyfunction]
#[pyo3(signature = (
    on_event, app_width, app_height, resizable, title, fullscreen, cursor_visible, visible = true
))]
// possibly more settings can be added
#[allow(clippy::too_many_arguments)]
fn run(
    py: Python<'_>,
    on_event: Py<PyAny>,
    app_width: u32,
    app_height: u32,
    resizable: bool,
    title: String,
    fullscreen: bool,
    cursor_visible: bool,
    visible: bool,
) -> PyResult<()> {
    // Release the GIL while the event loop runs, so other Python threads
    // (like the CS Academy Console) can run while it waits for events. It's
    // reacquired for each call into Python. The window and event loop aren't
    // Send, so they're created inside the closure.
    py.detach(move || {
        run_event_loop(
            on_event,
            app_width,
            app_height,
            resizable,
            title,
            fullscreen,
            cursor_visible,
            visible,
        )
    })
}

#[allow(clippy::too_many_arguments)]
fn run_event_loop(
    on_event: Py<PyAny>,
    app_width: u32,
    app_height: u32,
    resizable: bool,
    title: String,
    fullscreen: bool,
    cursor_visible: bool,
    visible: bool,
) -> PyResult<()> {
    let Ok(image) = image::load_from_memory(ICON_PNG) else {
        return Err(PyRuntimeError::new_err("Issue with opening icon image"));
    };
    let image_rgba = image.into_rgba8();
    let (width, height) = image_rgba.dimensions();
    let rgba = image_rgba.into_raw();
    let Ok(icon) = winit::window::Icon::from_rgba(rgba, width, height) else {
        return Err(PyRuntimeError::new_err("Issue with creating icon image"));
    };
    #[allow(unused_mut)]
    let mut window_attributes = Window::default_attributes()
        .with_min_inner_size(LogicalSize::new(1, 1))
        .with_inner_size(LogicalSize::new(app_width, app_height))
        .with_resizable(resizable)
        .with_title(title)
        .with_window_icon(Some(icon))
        .with_visible(false)
        .with_active(visible);
    #[cfg(target_os = "windows")]
    {
        use winit::platform::windows::WindowAttributesExtWindows;
        set_app_user_model_id();
        window_attributes = window_attributes.with_taskbar_icon(taskbar_icon());
    }

    let mut app = WinitApp {
        window_attributes,
        internals: None,
        last_tick: Instant::now(),
        last_mouse: Instant::now(),
        mouse_pending: false,
        pressed_buttons: Vec::new(),
        cursor_position: PhysicalPosition { x: 0.0, y: 0.0 },
        cursor_visible,
        py_surface: None,
        on_event,
        modifiers: Modifiers::default(),
        pressed_keys: HashMap::new(),
        error: None,
        fullscreen,
        visible,
        redraw_pending: false,
    };

    #[cfg(target_os = "macos")]
    ignore_saved_window_state();

    let mut event_loop_builder = EventLoop::<UserEvent>::with_user_event();
    // Keep a hidden app out of the Dock and from taking focus
    #[cfg(target_os = "macos")]
    if !visible {
        use winit::platform::macos::{ActivationPolicy, EventLoopBuilderExtMacOS};
        event_loop_builder
            .with_activation_policy(ActivationPolicy::Accessory)
            .with_activate_ignoring_other_apps(false);
    }
    let event_loop = event_loop_builder
        .build()
        .map_err(|_| PyRuntimeError::new_err("Issue with starting event loop"))?;
    event_loop.set_control_flow(ControlFlow::Wait);
    PROXY
        .set(event_loop.create_proxy())
        .map_err(|_| PyRuntimeError::new_err("Issue with starting proxy event loop"))?;
    let _ = event_loop.run_app(&mut app);

    let error = app.error.take();
    // The app holds Python objects, so release them while attached
    Python::attach(|_| drop(app));
    match error {
        None => Ok(()),
        Some(err) => Err(err),
    }
}

#[pyfunction]
fn quit() -> PyResult<()> {
    let proxy = PROXY
        .get()
        .ok_or_else(|| PyRuntimeError::new_err("Event loop proxy is not running"))?;
    proxy
        .send_event(UserEvent::Quit)
        .map_err(|_| PyRuntimeError::new_err("Failed to send quit event"))?;
    Ok(())
}

#[pyfunction]
fn set_active_screen(new_screen: String) -> PyResult<()> {
    let proxy = PROXY
        .get()
        .ok_or_else(|| PyRuntimeError::new_err("Event loop proxy is not running"))?;
    proxy
        .send_event(UserEvent::SetActiveScreen(new_screen))
        .map_err(|_| PyRuntimeError::new_err("Failed to send set_active_screen event"))?;
    Ok(())
}

#[pyfunction]
fn set_cursor_visible(visible: bool) -> PyResult<()> {
    let proxy = PROXY
        .get()
        .ok_or_else(|| PyRuntimeError::new_err("Event loop proxy is not running"))?;
    proxy
        .send_event(UserEvent::CursorVisible(visible))
        .map_err(|_| PyRuntimeError::new_err("Failed to send cursor_visible event"))?;
    Ok(())
}

#[pyfunction]
fn set_fullscreen(fullscreen: bool) -> PyResult<()> {
    let proxy = PROXY
        .get()
        .ok_or_else(|| PyRuntimeError::new_err("Event loop proxy is not running"))?;
    proxy
        .send_event(UserEvent::Fullscreen(fullscreen))
        .map_err(|_| PyRuntimeError::new_err("Failed to send fullscreen event"))?;
    Ok(())
}

fn send_injected_event(event: InjectedEvent) -> PyResult<()> {
    let proxy = PROXY
        .get()
        .ok_or_else(|| PyRuntimeError::new_err("Event loop proxy is not running"))?;
    proxy
        .send_event(UserEvent::Inject(event))
        .map_err(|_| PyRuntimeError::new_err("Failed to send injected event"))?;
    Ok(())
}

// Test-only: inject synthetic input, in logical coordinates
#[pyfunction]
fn _inject_mouse_move(x: f64, y: f64) -> PyResult<()> {
    send_injected_event(InjectedEvent::MouseMove(x, y))
}

// Test-only: button is 0 (left), 1 (middle), or 2 (right)
#[pyfunction]
fn _inject_mouse_button(button: u8, pressed: bool) -> PyResult<()> {
    send_injected_event(InjectedEvent::MouseButton(button, pressed))
}

// Test-only: a resize to 0x0 is what Windows sends on minimize
#[pyfunction]
fn _inject_resize(width: u32, height: u32) -> PyResult<()> {
    send_injected_event(InjectedEvent::Resize(width, height))
}

#[pyfunction]
fn set_size(width: u32, height: u32) -> PyResult<()> {
    let proxy = PROXY
        .get()
        .ok_or_else(|| PyRuntimeError::new_err("Event loop proxy is not running"))?;
    proxy
        .send_event(UserEvent::SetSize(width, height))
        .map_err(|_| PyRuntimeError::new_err("Failed to send set_size event"))?;
    Ok(())
}

#[pyfunction]
fn set_steps_per_second(steps_per_second: f64) {
    let nanos = if steps_per_second.is_finite() && steps_per_second > 0.0 {
        // At least 1ns, so a huge rate can't turn into "disabled"
        (1e9 / steps_per_second).max(1.0) as u64
    } else {
        0
    };
    STEP_INTERVAL_NANOS.store(nanos, Ordering::Relaxed);
}
/* BYEGAME */

#[pymodule]
fn cmu_graphics_helpers(m: &Bound<'_, PyModule>) -> PyResult<()> {
    let pygeo = PyModule::new(m.py(), "pygeo")?;
    pygeo.add_function(wrap_pyfunction!(union, &pygeo)?)?;
    pygeo.add_function(wrap_pyfunction!(edgesIntersect, &pygeo)?)?;
    m.add_submodule(&pygeo)?;
    m.py()
        .import("sys")?
        .getattr("modules")?
        .set_item("cmu_graphics_helpers.pygeo", pygeo)?;

    let wyvern = PyModule::new(m.py(), "wyvern")?;
    wyvern.add_class::<ImageSurface>()?;
    wyvern.add_class::<Canvas>()?;
    wyvern.add_class::<LineJoin>()?;
    wyvern.add_class::<FontWeight>()?;
    wyvern.add_class::<FontSlant>()?;
    wyvern.add_class::<Gradient>()?;
    wyvern.add_class::<WyvernImage>()?;
    wyvern.add_function(wrap_pyfunction!(load_image_from_path, &wyvern)?)?;
    wyvern.add_function(wrap_pyfunction!(load_image_from_bytes, &wyvern)?)?;
    wyvern.add_class::<WyvernSound>()?;
    wyvern.add_class::<PythonEvent>()?;
    wyvern.add_class::<MouseEvent>()?;
    wyvern.add_class::<KeyEvent>()?;
    wyvern.add_class::<ResizeEvent>()?;
    wyvern.add_function(wrap_pyfunction!(run, &wyvern)?)?;
    wyvern.add_function(wrap_pyfunction!(quit, &wyvern)?)?;
    wyvern.add_function(wrap_pyfunction!(set_active_screen, &wyvern)?)?;
    wyvern.add_function(wrap_pyfunction!(set_cursor_visible, &wyvern)?)?;
    wyvern.add_function(wrap_pyfunction!(set_fullscreen, &wyvern)?)?;
    wyvern.add_function(wrap_pyfunction!(set_size, &wyvern)?)?;
    wyvern.add_function(wrap_pyfunction!(set_steps_per_second, &wyvern)?)?;
    wyvern.add_function(wrap_pyfunction!(_inject_mouse_move, &wyvern)?)?;
    wyvern.add_function(wrap_pyfunction!(_inject_mouse_button, &wyvern)?)?;
    wyvern.add_function(wrap_pyfunction!(_inject_resize, &wyvern)?)?;
    m.add_submodule(&wyvern)?;
    m.py()
        .import("sys")?
        .getattr("modules")?
        .set_item("cmu_graphics_helpers.wyvern", wyvern)?;
    Ok(())
}
